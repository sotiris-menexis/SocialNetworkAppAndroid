package com.sotosmen.socialnetworkapp;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class Post {
    private String id;
    private String text;
    private long votes;
    private Date timestamp;
    private Thread ownerThread;
    private User creatorUser;

}
