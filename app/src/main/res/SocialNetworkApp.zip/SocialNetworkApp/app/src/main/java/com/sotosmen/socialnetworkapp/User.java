package com.sotosmen.socialnetworkapp;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class User {
    private String username;
    private String password;
    private String email;
    private String type;
    private String regNum;
    private String firstName;
    private String lastName;
    private Date timestamp;
    private List<Thread> threads;
    private List<Post> posts;
    private List<Message> messagesSent;
    private List<Message> messagesReceived;
    private List<Conversation> conversationsCreated;
    private List<Conversation> conversationsReceived;
}