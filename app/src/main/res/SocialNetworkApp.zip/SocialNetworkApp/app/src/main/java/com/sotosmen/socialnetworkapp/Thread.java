package com.sotosmen.socialnetworkapp;

import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class Thread {
    private String id;
    private User creatorUser;
    private String description;
    private Date timestamp;
    private long votes;
    List<Post> posts;
}
