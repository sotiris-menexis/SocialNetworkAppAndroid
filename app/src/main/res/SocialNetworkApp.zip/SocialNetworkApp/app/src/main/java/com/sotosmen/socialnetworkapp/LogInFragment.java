package com.sotosmen.socialnetworkapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class LogInFragment extends Fragment {
    public static View view;
    public static TextView login_title;
    public static EditText username_txt;
    public static EditText password_txt;
    public static Button login;
    public static Button signup;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view  = inflater.inflate(R.layout.loginlayout,container,false);
        initializeView();
        setUpListeners();

        return view;
    }

    public void initializeView(){
        login = (Button) view.findViewById(R.id.login_btn_login);
        signup = (Button) view.findViewById(R.id.signup_btn_login);
        username_txt = (EditText) view.findViewById(R.id.username_txt);
        password_txt = (EditText) view.findViewById(R.id.password_txt);
        login_title = (TextView) view.findViewById(R.id.app_title);
    }

    public void setUpListeners(){
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.startscreen_btn_anim));
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signup.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.startscreen_btn_anim));
                new BackgroundAdd().execute();
                /*Thread thread = new Thread(){
                    public void run(){

                    }
                };
                thread.start();*/
            }
        });
    }

    public void showUI(){
        login.setVisibility(View.VISIBLE);
        signup.setVisibility(View.VISIBLE);
        username_txt.setVisibility(View.VISIBLE);
        password_txt.setVisibility(View.VISIBLE);
        login_title.setVisibility(View.VISIBLE);
    }

    public void hideUI() {
        login.setVisibility(View.INVISIBLE);
        signup.setVisibility(View.INVISIBLE);
        username_txt.setVisibility(View.INVISIBLE);
        password_txt.setVisibility(View.INVISIBLE);
        login_title.setVisibility(View.INVISIBLE);
    }

    private class BackgroundAdd extends AsyncTask<Void,Void,Void> {
        String username = LogInFragment.username_txt.getText().toString().trim();
        String password = LogInFragment.password_txt.getText().toString().trim();
        String result="";
        HttpURLConnection connection = null;
        @Override
        protected Void doInBackground(Void... voids) {

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            //HttpURLConnection connection = null;
            String link = "http://192.168.1.3:80/phptestandroid/putuser.php?username="+username+"&password="+password;
            try {
                URL url = new URL(link);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                int response_code = connection.getResponseCode();
                result = String.valueOf(response_code);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Toast.makeText(getContext(),"Successfully put user " + result, Toast.LENGTH_SHORT).show();
            Toast.makeText(getContext(),"Successfully put user " + result, Toast.LENGTH_SHORT).show();
            super.onPostExecute(aVoid);
        }
    }

}