package com.sotosmen.socialnetworkapp;

public class FragmentsNames {
    public static String logInName = "LogInFrag";

    public FragmentsNames() {
    }
}